## Python Builder

<ul>
  <li>Still in progress</li>
  <li>author: John Richardson</li>
  <li>date: 2018-12-30</li>
  <li>version: 1.0</li>
</ul>

- [ ] Finish Linux Builder
- [ ] Finish Mac Builder
- [ ] Finish README
- [ ] Re work Code
- [ ] work on the installer
